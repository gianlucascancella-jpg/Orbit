import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight, CalendarDays, Check, ChevronLeft, ChevronRight, CircleHelp,
  CreditCard, LogOut, Menu, Plus, Settings, Sparkles, Trash2, Wallet, X
} from "lucide-react";
import { addMonths, format, isSameDay, isSameMonth, parseISO, startOfMonth } from "date-fns";
import { it } from "date-fns/locale";
import type { AppState, Transaction } from "./types";
import { buildHorizon, findBestWindows, formatEuro, heat } from "./engine";
import { isCloudConfigured, supabase } from "./supabase";
import { deleteTransaction, loadCloud, loadLocal, saveLocal, saveSettings, upsertTransaction } from "./storage";
import "./styles.css";

const money = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
const uid = () => crypto.randomUUID();

function App() {
  const [session, setSession] = useState<any>(null);
  const [state, setState] = useState<AppState>(() => loadLocal());
  const [loading, setLoading] = useState(isCloudConfigured);
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [selected, setSelected] = useState<Date | null>(new Date());
  const [modal, setModal] = useState<"tx" | "settings" | "login" | null>(null);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [toast, setToast] = useState("");

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        try { setState(await loadCloud(data.session.user.id)); }
        catch { setToast("Impossibile sincronizzare i dati cloud."); }
      }
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, next) => {
      setSession(next);
      if (next?.user) {
        try { setState(await loadCloud(next.user.id)); } catch {}
      }
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!isCloudConfigured || !session?.user) saveLocal(state);
  }, [state, session]);

  const days = useMemo(() => buildHorizon(state.transactions, month, state.settings.safetyBuffer, state.settings.weekendShift), [state, month]);
  const today = new Date();
  const current = days.find(d => isSameDay(d.date, today));
  const selectedDay = selected ? days.find(d => isSameDay(d.date, selected)) : current;
  const best = useMemo(() => findBestWindows(days, 150), [days]);

  const persistTx = async (tx: Transaction) => {
    setState(s => ({ ...s, transactions: s.transactions.some(x => x.id === tx.id) ? s.transactions.map(x => x.id === tx.id ? tx : x) : [...s.transactions, tx] }));
    try {
      if (session?.user) await upsertTransaction(session.user.id, tx);
      else saveLocal({ ...state, transactions: state.transactions.some(x => x.id === tx.id) ? state.transactions.map(x => x.id === tx.id ? tx : x) : [...state.transactions, tx] });
      setToast("Salvato");
    } catch { setToast("Salvato localmente, sincronizzazione non riuscita."); }
  };

  const removeTx = async (id: string) => {
    setState(s => ({ ...s, transactions: s.transactions.filter(x => x.id !== id) }));
    try { if (session?.user) await deleteTransaction(id); } catch {}
  };

  const persistSettings = async (next: AppState) => {
    setState(next);
    try {
      if (session?.user) await saveSettings(session.user.id, next);
      else saveLocal(next);
    } catch { setToast("Impostazioni salvate localmente."); }
  };

  if (loading) return <div className="splash"><div className="logoMark">O</div><span>Caricamento del tuo spazio...</span></div>;

  return (
    <div className="appShell">
      <header className="topbar glass">
        <div className="brand"><div className="logoMark">O</div><div><b>orbit</b><small>budget familiare</small></div></div>
        <div className="topActions">
          {isCloudConfigured && !session && <button className="ghostButton" onClick={() => setModal("login")}>Accedi</button>}
          {session && <button className="avatar" title="Esci" onClick={() => supabase?.auth.signOut()}>{(session.user.email?.[0] || "U").toUpperCase()}</button>}
          <button className="iconButton" onClick={() => setModal("settings")}><Settings size={19}/></button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div>
            <p className="eyebrow">OGGI · {format(today, "EEEE d MMMM", { locale: it })}</p>
            <h1>Quanto puoi<br/><em>spendere davvero?</em></h1>
          </div>
          <div className={`todayBubble ${heat(current?.spendable ?? 0)}`}>
            <span>Spendibilità oggi</span>
            <strong>{formatEuro(current?.spendable ?? 0)}</strong>
            <small>senza compromettere gli impegni futuri</small>
          </div>
        </section>

        <section className="metrics">
          <div className="metricBubble"><span>Saldo previsto</span><strong>{formatEuro(current?.balance ?? 0)}</strong></div>
          <div className="metricBubble income"><span>Prossima entrata</span><strong>{formatEuro(days.find(d => d.income > 0)?.income ?? 0)}</strong></div>
          <div className="metricBubble expense"><span>Prossima uscita</span><strong>{formatEuro(days.find(d => d.expense > 0)?.expense ?? 0)}</strong></div>
          <div className="metricBubble accent"><span>Weekend possibili</span><strong>{best.length}</strong></div>
        </section>

        <section className="calendarCard glass">
          <div className="calendarHeader">
            <div>
              <p className="eyebrow">ORIZZONTE 3 MESI</p>
              <h2>La tua liquidità, nel tempo.</h2>
            </div>
            <div className="monthNav">
              <button className="iconButton" onClick={() => setMonth(addMonths(month, -1))}><ChevronLeft/></button>
              <span>{format(month, "MMMM yyyy", { locale: it })}</span>
              <button className="iconButton" onClick={() => setMonth(addMonths(month, 1))}><ChevronRight/></button>
            </div>
          </div>
          <div className="legend"><span><i className="dot hot"/> Alta spendibilità</span><span><i className="dot warm"/> Buona</span><span><i className="dot cold"/> Bassa</span></div>
          <CalendarGrid month={month} days={days} selected={selected} onSelect={setSelected} />
        </section>

        <section className="insightRow">
          <div className="insight glass">
            <div className="insightIcon"><Sparkles/></div>
            <div><span className="eyebrow">IL MOMENTO GIUSTO</span><h3>{best[0] ? `Il prossimo spazio libero è ${format(best[0].date, "d MMMM", { locale: it })}.` : "Nessuna finestra sopra €150 nel periodo."}</h3><p>{best[0] ? `Puoi prevedere uno sfizio da ${formatEuro(Math.min(best[0].spendable, 300))} senza entrare in una zona critica.` : "Riduci una spesa o aggiungi una nuova entrata per creare margine."}</p></div>
            <ArrowRight/>
          </div>
          <div className="dayPanel glass">
            <div className="panelHead"><div><span className="eyebrow">{selectedDay ? format(selectedDay.date, "EEEE d MMMM", {locale: it}) : "SELEZIONA UN GIORNO"}</span><h3>{formatEuro(selectedDay?.spendable ?? 0)} <small>spendibili</small></h3></div><button className="addButton" onClick={() => {setEditing(null);setModal("tx")}}><Plus/></button></div>
            <div className="eventList">
              {(selectedDay?.events ?? []).length === 0 ? <div className="empty">Nessun movimento previsto.</div> : selectedDay?.events.map(e => <div className="event" key={e.id}><span className={`eventDot ${e.type}`}/><div><b>{e.title}</b><small>{e.category}</small></div><strong className={e.type}>{e.type === "income" ? "+" : "−"}{money.format(e.amount)}</strong></div>)}
            </div>
          </div>
        </section>

        <section className="transactionsSection">
          <div className="sectionTitle"><div><span className="eyebrow">DATI MODIFICABILI</span><h2>Entrate e impegni</h2></div><button className="primaryButton" onClick={() => {setEditing(null);setModal("tx")}}><Plus size={17}/> Nuovo movimento</button></div>
          <div className="transactionTable glass">
            {state.transactions.length === 0 ? <div className="empty big">Inizia aggiungendo stipendio, entrate o spese fisse.</div> : state.transactions.map(tx => <div className="txRow" key={tx.id}><div className={`txGlyph ${tx.type}`}><Wallet size={18}/></div><div className="txInfo"><b>{tx.title}</b><span>{tx.category} · {tx.frequency === "monthly" ? "ogni mese" : tx.frequency === "weekly" ? "ogni settimana" : tx.frequency === "yearly" ? "ogni anno" : "una volta"}</span></div><div className={tx.type === "income" ? "amount positive" : "amount"}>{tx.type === "income" ? "+" : "−"}{money.format(tx.amount)}</div><button className="rowAction" onClick={() => {setEditing(tx);setModal("tx")}}>Modifica</button><button className="rowDelete" onClick={() => removeTx(tx.id)}><Trash2 size={17}/></button></div>)}
          </div>
        </section>

        <footer><span>orbit</span><span>{session ? "Sincronizzazione cloud attiva" : "Modalità locale · collega Supabase per sincronizzare"}</span></footer>
      </main>

      {modal === "tx" && <TransactionModal initial={editing} globalShift={state.settings.weekendShift} onClose={() => setModal(null)} onSave={persistTx} onDelete={editing ? () => {removeTx(editing.id);setModal(null)} : undefined}/>}
      {modal === "settings" && <SettingsModal state={state} onClose={() => setModal(null)} onSave={persistSettings} />}
      {modal === "login" && <AuthModal onClose={() => setModal(null)} onSession={setSession}/>}
      {toast && <div className="toast" onAnimationEnd={() => setToast("")}><Check size={16}/>{toast}</div>}
    </div>
  );
}

function CalendarGrid({month, days, selected, onSelect}: {month: Date; days: any[]; selected: Date|null; onSelect: (d:Date)=>void}) {
  const first = startOfMonth(month);
  const leading = (first.getDay() + 6) % 7;
  const monthDays = days.filter(d => isSameMonth(d.date, month));
  const cells = [...Array(leading).fill(null), ...monthDays];
  return <div className="calendarGrid"><div className="weekNames">{["L","M","M","G","V","S","D"].map((x,i)=><span className={i>4?"weekend":""} key={i}>{x}</span>)}</div><div className="daysGrid">{cells.map((d,i) => d ? <button key={d.date.toISOString()} className={`dayCell ${heat(d.spendable)} ${selected && isSameDay(selected,d.date) ? "selected":""} ${d.date.getDay()===0||d.date.getDay()===6?"weekend":""}`} onClick={() => onSelect(d.date)}><span>{format(d.date,"d")}</span>{d.spendable > 0 && <b>{money.format(d.spendable).replace(",00","")}</b>}{d.events.length > 0 && <i/>}</button> : <div className="dayCell blank" key={`blank-${i}`}/>)}</div></div>;
}

function TransactionModal({initial, globalShift, onClose, onSave, onDelete}: {initial:Transaction|null; globalShift:boolean; onClose:()=>void; onSave:(t:Transaction)=>void; onDelete?:()=>void}) {
  const [title,setTitle]=useState(initial?.title ?? "");
  const [type,setType]=useState<"income"|"expense">(initial?.type ?? "income");
  const [amount,setAmount]=useState(String(initial?.amount ?? ""));
  const [date,setDate]=useState(initial?.date ?? format(new Date(),"yyyy-MM-dd"));
  const [frequency,setFrequency]=useState<any>(initial?.frequency ?? "monthly");
  const [category,setCategory]=useState(initial?.category ?? "Generale");
  const [shift,setShift]=useState(initial?.shift_weekend ?? globalShift);
  const submit=(e:React.FormEvent)=>{e.preventDefault(); if(!title||!amount)return; onSave({id:initial?.id??uid(),title,type,amount:Number(amount.replace(",",".")),date,frequency,category,shift_weekend:shift,active:true});onClose()};
  return <div className="modalBackdrop"><form className="modal glass" onSubmit={submit}><div className="modalTop"><div><span className="eyebrow">{initial?"MODIFICA":"NUOVO"}</span><h2>{type==="income"?"Entrata":"Uscita"}</h2></div><button type="button" className="iconButton" onClick={onClose}><X/></button></div><div className="segmented"><button type="button" className={type==="income"?"active income":""} onClick={()=>setType("income")}>Entrata</button><button type="button" className={type==="expense"?"active expense":""} onClick={()=>setType("expense")}>Uscita</button></div><label>Nome<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Es. Stipendio"/></label><div className="two"><label>Importo<input inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0"/></label><label>Data<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label></div><div className="two"><label>Ricorrenza<select value={frequency} onChange={e=>setFrequency(e.target.value)}><option value="once">Una volta</option><option value="monthly">Ogni mese</option><option value="weekly">Ogni settimana</option><option value="yearly">Ogni anno</option></select></label><label>Categoria<input value={category} onChange={e=>setCategory(e.target.value)}/></label></div><label className="switchLine"><span><b>Se cade nel weekend</b><small>Sposta questo movimento al primo giorno lavorativo successivo</small></span><input type="checkbox" checked={shift} onChange={e=>setShift(e.target.checked)}/></label><div className="modalActions">{onDelete&&<button type="button" className="dangerButton" onClick={onDelete}>Elimina</button>}<button type="button" className="ghostButton" onClick={onClose}>Annulla</button><button className="primaryButton" type="submit">{initial?"Aggiorna":"Salva movimento"}</button></div></form></div>
}

function SettingsModal({state,onClose,onSave}:{state:AppState;onClose:()=>void;onSave:(s:AppState)=>void}) {
  const [s,setS]=useState(state);
  return <div className="modalBackdrop"><div className="modal glass"><div className="modalTop"><div><span className="eyebrow">PREFERENZE</span><h2>Il tuo modo di vedere il denaro</h2></div><button className="iconButton" onClick={onClose}><X/></button></div><label className="switchLine"><span><b>Sposta le entrate del weekend</b><small>Selezionabile anche per ogni singola entrata.</small></span><input type="checkbox" checked={s.settings.weekendShift} onChange={e=>setS({...s,settings:{...s.settings,weekendShift:e.target.checked}})}/></label><label>Margine di sicurezza<input type="number" min="0" step="10" value={s.settings.safetyBuffer} onChange={e=>setS({...s,settings:{...s.settings,safetyBuffer:Number(e.target.value)}})}/><small>Somma che Orbit considera intoccabile.</small></label><div className="modalActions"><button className="ghostButton" onClick={onClose}>Annulla</button><button className="primaryButton" onClick={()=>{onSave(s);onClose()}}>Salva impostazioni</button></div></div></div>
}

function AuthModal({onClose,onSession}:{onClose:()=>void;onSession:(s:any)=>void}) {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [mode,setMode]=useState<"login"|"signup">("login"); const [msg,setMsg]=useState("");
  const submit=async(e:React.FormEvent)=>{e.preventDefault();if(!supabase)return;const res=mode==="login"?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password});if(res.error)setMsg(res.error.message);else{onSession(res.data.session);setMsg(mode==="signup"?"Controlla la tua email per confermare l'account.":"Accesso effettuato.");if(res.data.session)onClose()}};
  return <div className="modalBackdrop"><form className="modal auth glass" onSubmit={submit}><div className="modalTop"><div><span className="eyebrow">ACCOUNT</span><h2>{mode==="login"?"Bentornato.":"Crea il tuo spazio."}</h2></div><button type="button" className="iconButton" onClick={onClose}><X/></button></div><p className="authIntro">I movimenti vengono legati al tuo account e sincronizzati sul cloud. Niente ripartenze da zero.</p><label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6} autoComplete={mode==="login"?"current-password":"new-password"}/></label>{msg&&<div className="message">{msg}</div>}<button className="primaryButton full" type="submit">{mode==="login"?"Accedi":"Registrati"}</button><button type="button" className="linkButton" onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?"Non hai un account? Registrati":"Hai già un account? Accedi"}</button></form></div>
}

createRoot(document.getElementById("root")!).render(<App />);
